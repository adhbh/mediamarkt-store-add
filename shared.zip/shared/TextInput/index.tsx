import React, { useEffect, useState, useRef } from "react";
import {
    View,
    StyleSheet,
    TextInput,
    Animated,
} from "react-native";
import COLORS from "../../utils/colors";

const CustomTextInput = (props: any) => {
    const [value, setValue] = useState("");
    const moveText = useRef(new Animated.Value(0)).current;
    const changeFont = useRef(new Animated.Value(16)).current;

    useEffect(() => {
        if (value !== "") {
            moveTextTop();
        } else if (value === "") {
            moveTextBottom();
        }
    }, [value])

    const onChangeText = (text: string) => {
        setValue(text);
    };

    const onFocusHandler = () => {
        if (value !== "") {
            moveTextTop();
        }
    };

    const onBlurHandler = () => {
        if (value === "") {
            moveTextBottom();
        }
    };

    const moveTextTop = () => {
        Animated.timing(moveText, {
            toValue: 1.2,
            duration: 200,
            useNativeDriver: true,
        }).start();

        Animated.timing(changeFont, {
            toValue: 5,
            duration: 200,
            useNativeDriver: false
        })
    };

    const moveTextBottom = () => {
        Animated.timing(moveText, {
            toValue: 0,
            duration: 200,
            useNativeDriver: true,
        }).start();
    };

    const yVal = moveText.interpolate({
        inputRange: [0, 1],
        outputRange: [4, -20],
    });

    const animStyle = {
        transform: [
            {
                translateY: yVal,
            },
        ],
    };

    const fontAnimStyle = {
        fontSize: changeFont
    };

    return (
        <View style={styles.container}>
            <TextInput
                autoCapitalize={"none"}
                style={styles.input}
                value={value}
                onChangeText={(text: string) => onChangeText(text)}
                editable={true}
                onFocus={onFocusHandler}
                onBlur={onBlurHandler}
                blurOnSubmit
            />
            <Animated.View style={[styles.animatedStyle, animStyle]}>
                <Animated.Text style={[styles.label, fontAnimStyle]}>{props.placeholder}</Animated.Text>
            </Animated.View>
        </View>
    );
};
export default CustomTextInput;

const styles = StyleSheet.create({
    container: {
        marginBottom: 20,
        marginTop: 20,
        backgroundColor: COLORS.white,
        paddingTop: 5,
        paddingHorizontal: 10,
        borderWidth: 1,
        borderColor: COLORS.lightGrey,
        borderRadius: 10,
        width: "100%",
        justifyContent: 'center',
        height: 56,
    },
    icon: {
        width: 40,
        justifyContent: "center",
        alignItems: "center",
    },
    input: {
        fontSize: 16,
        height: 24,
        color: COLORS.darkGrey,
    },
    label: {
        color: COLORS.darkGrey,
        fontSize: 16,
    },
    animatedStyle: {
        top: 15,
        left: 15,
        position: 'absolute',
        borderRadius: 90,
        zIndex: 10000,
        backgroundColor: COLORS.white
    },
});
