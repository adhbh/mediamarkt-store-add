import {Modal, Pressable, StyleSheet, View} from "react-native";;
import COLORS from "../../utils/colors";

export default function CustomModal(props: any) {
    const { open, onRequestClose } = props;
    return <>
        {
            open ?
                <Pressable
                    style={{ position: 'absolute', width: '100%', height: '100%', backgroundColor: 'rgba(0, 0, 0, 0.4)' }}
                    onPress={onRequestClose}
                ><View /></Pressable>
                : null
        }
        <Modal
        animationType="slide"
        visible={open}
        transparent={true}
        >
        <View style={styles.bottomSheetView}>
            {props.children}
        </View>
    </Modal>
    </>
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    bottomSheetView: {
        flex: 1,
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
        marginTop: 22,
    },
    modalView: {
        backgroundColor: 'white',
        borderRadius: 20,
        padding: 35,
        width: '100%',
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5,
    },
});
