import {FlatList, Image, Pressable, SafeAreaView, StyleSheet, Text, TextInput, View} from 'react-native';
import PickupListItem from "../../shared/PickupListItem";
import COLORS from "../../utils/colors";
import {useState} from "react";
import CustomTextInput from "../../shared/TextInput";
import CustomModal from "../../shared/CustomModal";

const DATA = [
    {
        id: '1',
        title: 'First Item',
    },
    {
        id: '2',
        title: 'Second Item',
    },
    {
        id: '3',
        title: 'Second Item',
    },
    {
        id: '4',
        title: 'Second Item',
    },
    {
        id: '5',
        title: 'Second Item',
    },
    {
        id: '6',
        title: 'Second Item',
    },
    {
        id: '7',
        title: 'Second Item',
    },
    {
        id: '8',
        title: 'Second Item',
    },
    {
        id: '9',
        title: 'Second Item',
    },
    {
        id: '10',
        title: 'Second Item',
    },
    {
        id: '11',
        title: 'Second Item',
    },
    {
        id: '12',
        title: 'Second Item',
    },
];

export default function ParcelLists(props: any) {
    const { navigation } = props;

    const [modalVisible, setModalVisible] = useState(false);

    const onItemPressed = () => {
        navigation.navigate('Parcel List')
    }
    return (
        <SafeAreaView style={styles.container}>
            <View style={{ flex: 1,  marginTop: 30, marginLeft: 20, marginRight: 20 }}>
            <FlatList
                data={DATA}
                renderItem={({item}) => <PickupListItem onItemPressed={onItemPressed} />}
                keyExtractor={item => item.id}
                showsVerticalScrollIndicator={false}
                ItemSeparatorComponent={() => <View style={{ borderBottomWidth: 1, borderBottomColor: COLORS.lightGrey,         paddingBottom: 10,
                    marginTop: 6, marginBottom: 6 }} />}
                ListHeaderComponent={() => <View style={{ marginBottom: 17, marginTop: 48 }}>
                    <Text style={{ fontSize: 24, fontWeight: '500' }}>
                        Parcel lists
                    </Text>
                </View>}
            />
            </View>
            <View style={{ height: 100, justifyContent: 'center', alignItems: 'center' }}>
                <Pressable onPress={() => {
                    setModalVisible(true)
                }}>
                    <Image source={require('../../assets/RoundButton.png')} style={{
                        height: 80,
                        width: 80,
                    }}/>
                </Pressable>
            </View>
            <CustomModal open={modalVisible} onRequestClose={() => { setModalVisible(false) }}>
                <View style={styles.modalView}>
                    <Text style={styles.modalText}>Parcel and Carrier information</Text>
                    <CustomTextInput placeholder={'ID'}/>
                    <CustomTextInput placeholder={'Carrier ID'}/>
                    <Pressable
                        style={[styles.button]}
                        onPress={() => setModalVisible(!modalVisible)}>
                        <Text style={styles.textStyle}>ADD</Text>
                    </Pressable>
                </View>
            </CustomModal>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    centeredView: {
        flex: 1,
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
        marginTop: 22,
    },
    modalView: {
        backgroundColor: 'white',
        borderRadius: 20,
        padding: 20,
        width: '100%',
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5,
    },
    button: {
        borderRadius: 10,
        elevation: 2,
        backgroundColor: COLORS.red,
        width: '100%',
        height: 48,
        justifyContent: 'center',
        alignItems: 'center'
    },
    textStyle: {
        color: 'white',
        fontWeight: 'bold',
        textAlign: 'center',
    },
    modalText: {
        marginBottom: 15,
        textAlign: 'center',
        fontSize: 20,
        fontWeight: '500'
    },
    input: {
        height: 40,
        margin: 12,
        borderWidth: 1,
        padding: 10,
    },
});
